CREATE DATABASE  IF NOT EXISTS `cpmtest` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `cpmtest`;
-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: cpmtest
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping events for database 'cpmtest'
--

--
-- Dumping routines for database 'cpmtest'
--
/*!50003 DROP PROCEDURE IF EXISTS `close_trade` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `close_trade`(IN tradeid varchar(45))
BEGIN
	UPDATE cpmtest.tradehistory set trade_status = 'CLOSED',
		isProfit = case when total_sell_value > total_buy_value THEN 'PROFIT'
        when total_sell_value < total_buy_value THEN 'PROFIT'
        when total_sell_value = total_buy_value THEN 'BREAKEVEN' END
    where trade_id = tradeid;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `new_procedure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `new_procedure`( IN analystid varchar(45) ,  IN orderid varchar(45))
BEGIN
/* This procedure gets the new executed order details and opens a new trade record for the corresponding asset-market pair*/
	SELECT ANALYST_ID,ORDER_ID,ASSET_SYMBOL,MARKET_SYMBOL,ORDER_TYPE,LAST_EXECUTED_PRICE,LAST_ORDER_FILL,TOTAL_ORDER_FILL,QUANTITY,FEES,COMMISSION_SYMBOL,ORDER_TIME FROM 
	OPENORDERHISTORY WHERE ANALYST_ID =  analystid AND ORDER_ID = orderid 
		INTO @aid,@oid,@asset,@market,@otype,@lep,@lof,@tof,@q,@f,@cs,@otime;
	 
	 IF @otype = 'BUY' then
	 		INSERT INTO TRADEHISTORY (ANALYST_ID,ASSET_SYMBOL,MARKET_SYMBOL,TRADE_TYPE,INVESTED_VALUE,TOTAL_VOLUME,
            BUY_VOLUME,TOTAL_FEES,FEES_ASSET,LASTTRADETIME)
			VALUES(analystid,@asset,@market,@otype,(@lep*@lof),@tof,@q,@f,@cs,@otime);
        
	 END if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `open_new_trade` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `open_new_trade`( IN analystid varchar(45) ,  IN orderid varchar(45))
BEGIN
/* This procedure gets the new executed order details and opens a new trade record for the corresponding asset-market pair*/
	SELECT ANALYST_ID,ORDER_ID,ASSET_SYMBOL,MARKET_SYMBOL,ORDER_TYPE,LAST_EXECUTED_PRICE,LAST_ORDER_FILL,TOTAL_ORDER_FILL,QUANTITY,
    FEES,COMMISSION_SYMBOL,ORDER_TIME,TRADE_ID FROM OPENORDERHISTORY WHERE ANALYST_ID =  analystid AND ORDER_ID = orderid 
    INTO @aid,@oid,@asset,@market,@otype,@lep,@lof,@tof,@q,@f,@cs,@otime,@tid;
	 
	 IF @otype = 'BUY' then
		IF @cs <> 'BNB' THEN
			INSERT INTO TRADEHISTORY (ANALYST_ID,ASSET_SYMBOL,MARKET_SYMBOL,TRADE_TYPE,TOTAL_BUY_VALUE,TOTAL_VOLUME,
            BUY_VOLUME,TOKEN_FEES,LASTTRADETIME,TRADE_ID) VALUES(analystid,@asset,@market,@otype,(@lep*@lof),@tof,@q,@f,@otime,@tid);
		ELSE 
			INSERT INTO TRADEHISTORY (ANALYST_ID,ASSET_SYMBOL,MARKET_SYMBOL,TRADE_TYPE,TOTAL_BUY_VALUE,TOTAL_VOLUME,
            BUY_VOLUME,BNB_FEES,LASTTRADETIME,TRADE_ID) VALUES(analystid,@asset,@market,@otype,(@lep*@lof),@tof,@q,@f,@otime,@tid);
		END IF; 
	elseif @otype = 'SELL' THEN
		IF @cs <> 'BNB' THEN
			INSERT INTO TRADEHISTORY (ANALYST_ID,ASSET_SYMBOL,MARKET_SYMBOL,TRADE_TYPE,TOTAL_SELL_VALUE,TOTAL_VOLUME,
            SELL_VOLUME,MARKET_FEES,LASTTRADETIME,TRADE_ID) VALUES(analystid,@asset,@market,@otype,(@lep*@lof),@tof,@q,@f,@otime,@tid);
		else
			INSERT INTO TRADEHISTORY (ANALYST_ID,ASSET_SYMBOL,MARKET_SYMBOL,TRADE_TYPE,TOTAL_SELL_VALUE,TOTAL_VOLUME,
            SELL_VOLUME,BNB_FEES,LASTTRADETIME,TRADE_ID) VALUES(analystid,@asset,@market,@otype,(@lep*@lof),@tof,@q,@f,@otime,@tid);
		END IF;
	 END if;
     
UPDATE account_snapshot 
SET 
    total_trades = total_trades + 1
WHERE
    analyst_id = analystid
        AND asset = @asset;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_trade` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_trade`(IN analystid VARCHAR(45), IN ORDERID VARCHAR(45),IN inTRADE_ID VARCHAR(45))
BEGIN
/* NEED A LINE OF CODE THAT WILL SKIP TRADE UPDATE IF THE TRADE IS ALREADY CLOSED*/

	SELECT ORDER_TYPE,LAST_EXECUTED_PRICE,LAST_ORDER_FILL,TOTAL_ORDER_FILL,
    FEES,COMMISSION_SYMBOL,ORDER_TIME FROM OPENORDERHISTORY WHERE ANALYST_ID =  analystid AND ORDER_ID = orderid 
    INTO @otype,@lep,@lof,@tof,@f,@cs,@otime;
    
	IF @otype = 'BUY' THEN
		IF @cs <> 'BNB' THEN
			UPDATE TRADEHISTORY SET TOTAL_BUY_VALUE = TOTAL_BUY_VALUE+( @lep*@lof), BUY_VOLUME=BUY_VOLUME+@lof,
			TOKEN_FEES=TOKEN_FEES+@f,LASTTRADETIME=@otime WHERE TRADE_ID = inTRADE_ID;
		else
			UPDATE TRADEHISTORY SET TOTAL_BUY_VALUE = TOTAL_BUY_VALUE+( @lep*@lof), BUY_VOLUME=BUY_VOLUME+@lof,
			BNB_FEES=BNB_FEES+@f,LASTTRADETIME=@otime WHERE TRADE_ID = inTRADE_ID;
		END IF;
	ELSEIF @otype = 'SELL' THEN
		IF @cs <> 'BNB' THEN
			UPDATE TRADEHISTORY SET TOTAL_SELL_VALUE = TOTAL_SELL_VALUE+( @lep*@lof), SELL_VOLUME= SELL_VOLUME+@lof,
				MARKET_FEES=BNB_FEES+@f,LASTTRADETIME=@otime WHERE TRADE_ID = inTRADE_ID;
		else
			UPDATE TRADEHISTORY SET TOTAL_SELL_VALUE = TOTAL_SELL_VALUE+( @lep*@lof), SELL_VOLUME= SELL_VOLUME+@lof,
				BNB_FEES=BNB_FEES+@f,LASTTRADETIME=@otime WHERE TRADE_ID = inTRADE_ID;
        END IF;
	END IF;

	SELECT 
    BUY_VOLUME, SELL_VOLUME
FROM
    TRADEHISTORY
WHERE
    TRADE_ID = inTRADE_ID INTO @buyvolume , @sellvolume; 
    IF @buyvolume = @sellvolume THEN
		CALL close_trade(inTRADE_ID);
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-11 16:21:34
